





image monika_room_day = "mod_assets/DaytimeMonikaRoom/monika_day_room.png"

image monika_bg_day = "mod_assets/DaytimeMonikaRoom/monika_day_bg.png"


image room_mask3 = Movie(channel="window_3", play="mod_assets/DaytimeMonikaRoom/window_3.webm",mask=None,image="mod_assets/DaytimeMonikaRoom/window_3_fallback.png")
image room_mask4 = Movie(channel="window_4", play="mod_assets/DaytimeMonikaRoom/window_4.webm",mask=None,image="mod_assets/DaytimeMonikaRoom/window_4_fallback.png")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
