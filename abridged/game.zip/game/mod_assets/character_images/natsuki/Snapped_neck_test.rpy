

label natsuki_snapped_neck_test:

    stop music fadeout 2.0
    scene bg residential_day
    with dissolve_scene_full
    play music t2

    $ swoosh_f()
    show natsuki u121111 at r11
    n "This is me in my normal pose!"
    play sound "sfx/crack.ogg"
    show natsuki n125124
    n "And now I'm really obviously NOT!"
    n n312246 "Hey, this is kind of fun, in an incredibly grim way!"
    play sound "sfx/crack.ogg"
    n u114271 "Awww! No fair."

    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
