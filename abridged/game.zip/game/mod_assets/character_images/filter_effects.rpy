















init python:
    def bw(image): 
        return im.MatrixColor(image, im.matrix.desaturate())

    def cloudy(image, darken_sky = False): 
        custom_matrix = im.matrix.identity()
        if darken_sky:
            
            custom_matrix = [ 0.45, 0.15, 0.4, 0.0, 0.0, 0.2, 0.5, 0.3, 0.0, 0.0, 0.25, 0.25, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0 ]
        
        image = im.MatrixColor(image, custom_matrix) 
        return im.MatrixColor(image, im.matrix.saturation(0.7))

    def dawn(image): 
        return im.MatrixColor(image, im.matrix.tint(0.5, 0.4, 0.6))

    def evening(image): 
        return im.MatrixColor(image, im.matrix.tint(0.6, 0.6, 0.7))

    def flip(image): 
        return im.Flip(image, horizontal=True)

    def ghost(image, a = 0.8): 
        return im.MatrixColor(image,  im.matrix.desaturate() * im.matrix.tint(0.71, 1.0, 0.95) * im.matrix.opacity(a))

    def gray(image, level=0.0): 
        
        return im.MatrixColor(image, im.matrix.saturation(level))

    def morning(image): 
        return im.MatrixColor(image, im.matrix.tint(0.8, 0.7, 0.6))

    def night(image): 
        return im.MatrixColor(image, im.matrix.tint(0.4, 0.4, 0.6))

    def sepia(image): 
        return im.Sepia(image)

    def shadow(image): 
        return im.MatrixColor(image, im.matrix.colorize("#000", "#000"))

    def sunset(image): 
        return im.MatrixColor(image, im.matrix.tint(1.0, 0.8, 0.8))

    def white(image): 
        return im.MatrixColor(image, im.matrix.colorize("#fff", "#fff"))


    def getCharacterImage(char, expression="1a"): 
        return renpy.display.image.images.get((char, expression), None)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
