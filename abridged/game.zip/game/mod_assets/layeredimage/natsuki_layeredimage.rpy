










layeredimage natsuki turned: 



    group outfit: 
        attribute uniform default null
        attribute casual null
        attribute posture null 




    group mood if_any(["ff","fs"]):


        attribute neut default null 
        attribute happ null if_all(["ff"]) 
        attribute sad null if_any(["ff","fs"])
        attribute anno null if_all(["ff"])
        attribute angr null if_all(["ff"]) 
        attribute vang null if_all(["ff"]) 
        attribute cry null if_all(["fs"]) 
        attribute laug null if_all(["ff"]) 
        attribute worr null if_all(["ff"]) 
        attribute lsur null if_all(["ff"]) 
        attribute vsur null if_all(["ff"]) 
        attribute shoc null if_all(["ff"]) 

    group blush: 
        attribute nobl default null 
        attribute awkw null 
        attribute blus null 

    group left: 
        anchor (0,0) subpixel (True)
        yoffset (-0.5)
        attribute ldown default if_all(["uniform"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_left_down.png"
        attribute ldown default if_all(["casual"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_casual_left_down.png"
        attribute ldown default if_all(["posture"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_posture_left_down.png"
        attribute lhip if_all(["uniform"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_left_hip.png"
        attribute lhip if_all(["casual"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_casual_left_hip.png"
        attribute lhip if_all(["posture"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_posture_left_hip.png"
        attribute lpoint if_all(["uniform"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_left_point.png"
        attribute lpoint if_all(["casual"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_casual_left_point.png"
        attribute lknife if_all(["uniform"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_left_knife.png"

    group right: 
        anchor (0,0) subpixel (True)
        yoffset (-0.5)
        attribute rdown default if_all(["uniform"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_right_down.png"
        attribute rdown default if_all(["casual"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_casual_right_down.png"
        attribute rdown default if_all(["posture"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_posture_right_down.png"
        attribute rhip if_all(["uniform"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_right_hip.png"
        attribute rhip if_all(["casual"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_casual_right_hip.png"
        attribute rhip if_all(["posture"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_posture_right_hip.png"
        attribute rknife if_all(["uniform"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_right_knife.png"


    group head:
        anchor (0,0) subpixel (True)
        attribute ff default: 
            "mod_assets/layeredimage/natsuki/natsuki_turned_facebase.png"
        attribute fs: 
            "mod_assets/layeredimage/natsuki/natsuki_turned_facesad.png"
        attribute fta: 
            "mod_assets/layeredimage/natsuki/natsuki_turned_faceturnedaway.png"


    group mouth if_not(["fta","fs"]) if_all(["ff"]):
        anchor (0,0) subpixel (True)


        attribute cm default if_any(["neut","anno","worr","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_6.png"
        attribute cm default if_all(["happ"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_1.png"
        attribute cm default if_any(["sad","angr","vsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_9.png"
        attribute cm default if_any(["vang","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_5.png"
        attribute cm default if_all(["laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_8.png"


        attribute om if_all(["neut"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_3.png"
        attribute om if_any(["happ","laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_2.png"
        attribute om if_any(["sad","anno","worr","lsur","vsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_4.png"
        attribute om if_all(["angr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_7.png"
        attribute om if_any(["vang","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_a.png"



        attribute m1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_4.png"
        attribute m5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_5.png"
        attribute m6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_6.png"
        attribute m7:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_7.png"
        attribute m8:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_8.png"
        attribute m9:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_9.png"
        attribute ma:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_a.png"
        attribute mb:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_b.png"
        attribute mc:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_c.png"
        attribute md:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_d.png"
        attribute me:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_e.png"
        attribute mf:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_f.png"









    group nose if_not(["fs","fta"]) if_all(["ff"]):
        anchor (0,0) subpixel (True)

        attribute nose default if_all(["nobl"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_1.png"
        attribute nose if_all(["awkw"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_2.png"
        attribute nose if_all(["blus"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_2.png"


        attribute n1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_2.png"

    group eyes if_not(["fs","fta"]) if_all(["ff"]):
        anchor (0,0) subpixel (True)

        attribute oe default if_any(["neut","happ","laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_1.png"
        attribute oe default if_any(["sad","worr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_3.png"
        attribute oe default if_all(["anno"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_d.png"
        attribute oe default if_any(["angr","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_2.png"
        attribute oe default if_any(["vang","vsur","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_7.png"



        attribute ce if_any(["neut","happ","laug","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_4.png"
        attribute ce if_any(["sad","worr","anno","angr","vang","vsur","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_5.png"


        attribute e1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_6.png"
        attribute e7:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_7.png"
        attribute e8:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_8.png"
        attribute e9:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_9.png"
        attribute ea:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_a.png"
        attribute eb:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_b.png"
        attribute ec:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_c.png"
        attribute ed:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_d.png"
        attribute ee:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_e.png"
        attribute ef:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_f.png"
        attribute eg:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_g.png"
        attribute eh:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_h.png"



    group brow if_not(["fs","fta"]) if_all(["ff"]): 
        anchor (0,0) subpixel (True)

        attribute brow default if_all(["neut"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_1.png"
        attribute brow default if_any(["happ","lsur","worr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_3.png"
        attribute brow default if_any(["sad","laug","vsur","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_4.png"
        attribute brow default if_any(["anno","angr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_2.png"
        attribute brow default if_all(["vang"]) if_not(["ce"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_2.png"
        attribute brow default if_all(["vang","ce"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_5.png"



        attribute b1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_1.png"
        attribute b2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_2.png"
        attribute b3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_3.png"
        attribute b4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_4.png"
        attribute b5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_5.png"
        attribute b6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_6.png"
        attribute b7:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_7.png"





    group mouth if_not(["ff","fta"]) if_all(["fs"]):
        anchor (0,0) subpixel (True)

        attribute cm default if_all(["neut"]): 
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_1.png"
        attribute cm default if_any(["sad","cry"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_2.png"
        attribute om: 
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_3.png"



        attribute m1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_3.png"



    group nose if_not(["ff","fta"]) if_all(["fs"]):
        anchor (0,0) subpixel (True)

        attribute nose default if_all(["nobl"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_1.png"
        attribute nose default if_all(["awkw"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_2.png"
        attribute nose default if_all(["blus"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_3.png"



        attribute n1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_2.png"
        attribute n3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_3.png"




    group eyes if_not(["ff","fta"]) if_all(["fs"]):
        anchor (0,0) subpixel (True)

        attribute oe default if_all(["neut"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_1.png"
        attribute oe default if_all(["sad"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_2.png"
        attribute oe default if_all(["cry"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_3.png"


        attribute ce if_all(["neut"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_4.png"
        attribute ce if_all(["sad"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_5.png"
        attribute ce if_all(["cry"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_6.png"


        attribute e1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_6.png"





layeredimage natsuki cross: 

    group outfit:
        anchor (0,0) subpixel (True)
        attribute uniform default:
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_crossed.png"
        attribute casual:
            "mod_assets/layeredimage/natsuki/natsuki_turned_casual_crossed.png"


    group head:
        anchor (0,0) subpixel (True)
        xoffset (18)
        yoffset (22)

        attribute ff default: 
            "mod_assets/layeredimage/natsuki/natsuki_turned_facebase.png"
        attribute fs: 
            "mod_assets/layeredimage/natsuki/natsuki_turned_facesad.png"
        attribute fta: 
            "mod_assets/layeredimage/natsuki/natsuki_turned_faceturnedaway.png"

    group mood if_not(["fta"]):


        attribute neut default null 
        attribute happ null if_all(["ff"]) 
        attribute sad null if_any(["ff","fs"])
        attribute anno null if_all(["ff"])
        attribute angr null if_all(["ff"]) 
        attribute vang null if_all(["ff"]) 
        attribute cry null if_all(["fs"]) 
        attribute laug null if_all(["ff"]) 
        attribute worr null if_all(["ff"]) 
        attribute lsur null if_all(["ff"]) 

    group blush: 
        attribute nobl default null 
        attribute awkw null 
        attribute blus null 


    group mouth if_not(["fs","fta"]) if_all(["ff"]): 
        anchor (0,0) subpixel (True)
        xoffset (18)
        yoffset (22)


        attribute cm default if_any(["neut","anno","worr","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_6.png"
        attribute cm default if_all(["happ"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_1.png"
        attribute cm default if_any(["sad","angr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_9.png"
        attribute cm default if_all(["vang"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_5.png"
        attribute cm default if_all(["laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_8.png"


        attribute om if_all(["neut"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_3.png"
        attribute om if_any(["happ","laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_2.png"
        attribute om if_any(["sad","anno","worr","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_4.png"
        attribute om if_all(["angr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_7.png"
        attribute om if_all(["vang"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_a.png"


        attribute m1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_4.png"
        attribute m5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_5.png"
        attribute m6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_6.png"
        attribute m7:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_7.png"
        attribute m8:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_8.png"
        attribute m9:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_9.png"
        attribute ma:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_a.png"
        attribute mb:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_b.png"
        attribute mc:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_c.png"
        attribute md:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_d.png"
        attribute me:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_e.png"
        attribute mf:
            "mod_assets/layeredimage/natsuki/natsuki_turned_mouth_f.png"





    group nose if_not(["fs","fta"]) if_all(["ff"]):
        anchor (0,0) subpixel (True)
        xoffset (18)
        yoffset (22)


        attribute nose default if_all(["nobl"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_1.png"
        attribute nose default if_all(["awkw"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_2.png"
        attribute nose default if_all(["blus"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_2.png"


        attribute n1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_nose_2.png"

    group eyes if_not(["fs","fta"]) if_all(["ff"]):
        anchor (0,0) subpixel (True)
        xoffset (18)
        yoffset (22)


        attribute oe default if_any(["neut","happ","laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_1.png"
        attribute oe default if_any(["sad","worr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_3.png"
        attribute oe default if_all(["anno"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_d.png"
        attribute oe default if_any(["angr","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_2.png"
        attribute oe default if_all(["vang"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_7.png"



        attribute ce if_any(["neut","happ","laug","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_4.png"
        attribute ce if_any(["sad","worr","anno","angr","vang"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_5.png"


        attribute e1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_6.png"
        attribute e7:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_7.png"
        attribute e8:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_8.png"
        attribute e9:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_9.png"
        attribute ea:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_a.png"
        attribute eb:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_b.png"
        attribute ec:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_c.png"
        attribute ed:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_d.png"
        attribute ee:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_e.png"
        attribute ef:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_f.png"
        attribute eg:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_g.png"
        attribute eh:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyes_h.png"



    group brow if_not(["fs","fta"]) if_all(["ff"]): 
        anchor (0,0) subpixel (True)
        xoffset (18)
        yoffset (22)


        attribute brow default if_all(["neut"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_1.png"
        attribute brow default if_any(["happ","lsur","worr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_3.png"
        attribute brow default if_any(["sad","laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_4.png"
        attribute brow default if_any(["anno","angr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_2.png"
        attribute brow default if_all(["vang"]) if_not(["ce"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_2.png"
        attribute brow default if_all(["vang","ce"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_5.png"



        attribute b1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_1.png"
        attribute b2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_2.png"
        attribute b3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_3.png"
        attribute b4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_4.png"
        attribute b5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_5.png"
        attribute b6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_6.png"
        attribute b7:
            "mod_assets/layeredimage/natsuki/natsuki_turned_eyebrows_7.png"





    group mouth if_not(["ff","fta"]) if_all(["fs"]):
        anchor (0,0) subpixel (True)
        xoffset (18)
        yoffset (22)

        attribute cm default: 
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_1.png"
        attribute om: 
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_3.png"



        attribute m1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_mouth_3.png"



    group nose if_not(["ff","fta"]) if_all(["fs"]):
        anchor (0,0) subpixel (True)
        xoffset (18)
        yoffset (22)


        attribute nose default if_all(["nobl"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_1.png"
        attribute nose default if_all(["awkw"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_2.png"
        attribute nose default if_all(["blus"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_3.png"



        attribute n1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_2.png"
        attribute n3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_nose_3.png"




    group eyes if_not(["ff","fta"]) if_all(["fs"]):
        anchor (0,0) subpixel (True)
        xoffset (18)
        yoffset (22)


        attribute oe default if_not(["cry"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_1.png"
        attribute oe default if_all(["cry"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_2.png"


        attribute ce if_not(["cry"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_4.png"
        attribute ce if_all(["cry"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_5.png"


        attribute e1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_sad_eyes_6.png"



layeredimage natsuki neck: 



    group mood:


        attribute neut default null 
        attribute happ null if_all(["ff"]) 
        attribute sad null if_any(["ff","fs"])
        attribute anno null if_all(["ff"])
        attribute angr null if_all(["ff"]) 
        attribute vang null if_all(["ff"]) 
        attribute laug null if_all(["ff"]) 
        attribute worr null if_all(["ff"]) 
        attribute lsur null if_all(["ff"]) 
        attribute vsur null if_all(["ff"]) 
        attribute shoc null if_all(["ff"]) 

    group blush: 
        attribute nobl default null
        attribute awkw null 
        attribute blus null 

    group left: 
        anchor (0,0) subpixel (True)
        attribute ldown default:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_uniform_left_down.png"
        attribute lhip:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_uniform_left_hip.png"
        attribute lpoint:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_uniform_left_point.png"
        attribute lknife:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_uniform_left_knife.png"

    group right: 
        anchor (0,0) subpixel (True)
        attribute rdown default:
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_right_down.png"
        attribute rhip:
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_right_hip.png"
        attribute rknife if_all(["uniform"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_uniform_right_knife.png"


    always "mod_assets/layeredimage/natsuki/natsuki_turned_neck_uniform_facebase.png"

    group mouth: 
        anchor (0,0) subpixel (True)


        attribute cm default if_any(["neut","anno","worr","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_6.png"
        attribute cm default if_all(["happ"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_1.png"
        attribute cm default if_any(["sad","angr","vsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_9.png"
        attribute cm default if_any(["vang","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_5.png"
        attribute cm default if_all(["laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_8.png"


        attribute om if_all(["neut"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_3.png"
        attribute om if_any(["happ","laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_2.png"
        attribute om if_any(["sad","anno","worr","lsur","vsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_4.png"
        attribute om if_all(["angr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_7.png"
        attribute om if_any(["vang","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_a.png"



        attribute m1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_4.png"
        attribute m5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_5.png"
        attribute m6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_6.png"
        attribute m7:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_7.png"
        attribute m8:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_8.png"
        attribute m9:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_9.png"
        attribute ma:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_a.png"
        attribute mb:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_b.png"
        attribute mc:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_c.png"
        attribute md:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_d.png"
        attribute me:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_e.png"
        attribute mf:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_mouth_f.png"





    group nose: 
        anchor (0,0) subpixel (True)

        attribute nose default if_all(["nobl"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_nose_1.png"
        attribute nose default if_all(["awkw"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_nose_2.png"
        attribute nose default if_all(["blus"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_nose_2.png"



        attribute n1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_nose_2.png"




    group eyes:
        anchor (0,0) subpixel (True)

        attribute oe default if_any(["neut","happ","laug"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_1.png"
        attribute oe default if_any(["sad","worr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_3.png"
        attribute oe default if_all(["anno"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_d.png"
        attribute oe default if_any(["angr","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_2.png"
        attribute oe default if_any(["vang","vsur","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_7.png"



        attribute ce if_any(["neut","happ","laug","lsur"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_4.png"
        attribute ce if_any(["sad","worr","anno","angr","vang","vsur","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_5.png"


        attribute e1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_6.png"
        attribute e7:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_7.png"
        attribute e8:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_8.png"
        attribute e9:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_9.png"
        attribute ea:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_a.png"
        attribute eb:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_b.png"
        attribute ec:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_c.png"
        attribute ed:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_d.png"
        attribute ee:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_e.png"
        attribute ef:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_f.png"
        attribute eg:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_g.png"
        attribute eh:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyes_h.png"




    group brow:
        anchor (0,0) subpixel (True)

        attribute brow default if_all(["neut"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_1.png"
        attribute brow default if_any(["happ","lsur","worr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_3.png"
        attribute brow default if_any(["sad","laug","vsur","shoc"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_4.png"
        attribute brow default if_any(["anno","angr"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_2.png"
        attribute brow default if_all(["vang"]) if_not(["ce"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_2.png"
        attribute brow default if_all(["vang","ce"]):
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_5.png"



        attribute b1:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_1.png"
        attribute b2:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_2.png"
        attribute b3:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_3.png"
        attribute b4:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_4.png"
        attribute b5:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_5.png"
        attribute b6:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_6.png"
        attribute b7:
            "mod_assets/layeredimage/natsuki/natsuki_turned_neck_eyebrows_7.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
