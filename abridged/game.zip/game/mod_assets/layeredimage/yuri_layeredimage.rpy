

layeredimage yuri turned: 

    always "mod_assets/layeredimage/yuri/yuri_turned_facebase.png" 

    group outfit: 
        attribute uniform default null
        attribute casual null
        attribute hoodie null
        attribute stab null


    group mood: 

        attribute neut default null 
        attribute happ null 
        attribute worr null 
        attribute angr null 
        attribute vang null 
        attribute yand null 
        attribute flus null 
        attribute lsur null 
        attribute vsur null 
        attribute shoc null 

    group blush: 
        attribute nobl default null 
        attribute awkw null 
        attribute blus null 


    group left if_not(["stab"]):
        anchor (0,0) subpixel (True)
        yoffset (-0.5)
        xoffset (0.5)

        attribute ldown default if_all(["uniform"]):
            "mod_assets/layeredimage/yuri/yuri_turned_uniform_left_down.png"
        attribute lup if_any(["rup","rcut"]) if_all(["uniform"]):
            "mod_assets/layeredimage/yuri/yuri_turned_uniform_left_up.png"
        attribute lknife if_all(["uniform"]):
            "mod_assets/layeredimage/yuri/yuri_turned_uniform_left_knife.png"


        attribute ldown default if_all(["casual"]):
            "mod_assets/layeredimage/yuri/yuri_turned_casual_left_down.png"
        attribute lup if_any(["rup","rcut"]) if_all(["casual"]):
            "mod_assets/layeredimage/yuri/yuri_turned_casual_left_up.png"


        attribute ldown default if_all(["hoodie"]):
            "mod_assets/layeredimage/yuri/yuri_turned_hoodie_left_down.png"
        attribute lup if_any(["rup","rcut"]) if_all(["hoodie"]):
            "mod_assets/layeredimage/yuri/yuri_turned_hoodie_left_up.png"


    group right if_not(["stab"]):
        anchor (0,0) subpixel (True)
        yoffset (-0.5)
        attribute rdown default if_all(["uniform"]):
            "mod_assets/layeredimage/yuri/yuri_turned_uniform_right_down.png"
        attribute rup if_all(["uniform"]):
            "mod_assets/layeredimage/yuri/yuri_turned_uniform_right_up.png"
        attribute rknife if_all(["uniform"]):
            "mod_assets/layeredimage/yuri/yuri_turned_uniform_right_knife.png"
        attribute rcut if_all(["uniform"]):
            "mod_assets/layeredimage/yuri/yuri_turned_uniform_right_cut.png"


        attribute rdown default if_all(["casual"]):
            "mod_assets/layeredimage/yuri/yuri_turned_casual_right_down.png"
        attribute rup if_all(["casual"]):
            "mod_assets/layeredimage/yuri/yuri_turned_casual_right_up.png"


        attribute rdown default if_all(["hoodie"]):
            "mod_assets/layeredimage/yuri/yuri_turned_hoodie_right_down.png"
        attribute rup if_all(["hoodie"]):
            "mod_assets/layeredimage/yuri/yuri_turned_hoodie_right_up.png"
        attribute rcut if_all(["hoodie"]):
            "mod_assets/layeredimage/yuri/yuri_turned_hoodie_right_cut.png"

    group body_stab: 
        anchor (0,0) subpixel (True)
        yoffset (-0.5)


        attribute prestab:
            "mod_assets/layeredimage/yuri/yuri_turned_stab_1.png"
        attribute s_in:
            "mod_assets/layeredimage/yuri/yuri_turned_stab_4.png"
        attribute s_out:
            "mod_assets/layeredimage/yuri/yuri_turned_stab_5.png"
        attribute stab_loop_normal:
            "stabbing_n"
        attribute stab_loop_fast:
            "stabbing_f"
        attribute stab_loop_turbo:
            "stabbing_t"
        attribute stab_loop_normal_start:
            "stabbing_n_start"
        attribute stab_loop_fast_start:
            "stabbing_f_start"
        attribute stab_loop_turbo_start:
            "stabbing_t_start"
        attribute stab_loop_normal_end:
            "stabbing_n_end"
        attribute stab_loop_fast_end:
            "stabbing_f_end"
        attribute stab_loop_turbo_end:
            "stabbing_t_end"


        attribute stab1:
            "mod_assets/layeredimage/yuri/yuri_turned_stab_1.png"
        attribute stab2:
            "mod_assets/layeredimage/yuri/yuri_turned_stab_2.png"
        attribute stab3:
            "mod_assets/layeredimage/yuri/yuri_turned_stab_3.png"
        attribute stab4:
            "mod_assets/layeredimage/yuri/yuri_turned_stab_4.png"
        attribute stab5:
            "mod_assets/layeredimage/yuri/yuri_turned_stab_5.png"
        attribute stab6:
            "mod_assets/layeredimage/yuri/yuri_turned_stab_6.png"


    group placeholder: 
        attribute tape:
            "mod_assets/layeredimage/yuri/yuri_duct_tape.png"

    group mouth:
        anchor (0,0) subpixel (True)

        attribute cm default if_any(["neut","flus","lsur"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_3.png"
        attribute cm default if_all(["happ"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_1.png"
        attribute cm default if_any(["worr","angr","vsur"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_h.png"
        attribute cm default if_all(["vang"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_b.png"
        attribute cm default if_all(["yand"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_a.png"
        attribute cm default if_all(["shoc"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_4.png"


        attribute om if_any(["neut","angr","vsur"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_6.png"
        attribute om if_any(["happ","yand"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_2.png"
        attribute om if_any(["worr","lsur"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_5.png"
        attribute om if_any(["vang","shoc"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_8.png"
        attribute om if_all(["flus"]):
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_7.png"


        attribute m1:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_4.png"
        attribute m5:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_5.png"
        attribute m6:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_6.png"
        attribute m7:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_7.png"
        attribute m8:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_8.png"
        attribute m9:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_9.png"
        attribute ma:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_a.png"
        attribute mb:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_b.png"
        attribute mc:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_c.png"
        attribute md:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_d.png"
        attribute me:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_e.png"
        attribute mf:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_f.png"
        attribute mg:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_g.png"
        attribute mh:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_h.png"
        attribute mi:
            "mod_assets/layeredimage/yuri/yuri_turned_mouth_i.png"



    group nose:
        anchor (0,0) subpixel (True)


        attribute nose default if_all(["nobl"]):
            "mod_assets/layeredimage/yuri/yuri_turned_nose_1.png"
        attribute nose default if_all(["awkw"]):
            "mod_assets/layeredimage/yuri/yuri_turned_nose_3.png"
        attribute nose default if_all(["blus"]):
            "mod_assets/layeredimage/yuri/yuri_turned_nose_2.png"



        attribute n1:
            "mod_assets/layeredimage/yuri/yuri_turned_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/yuri/yuri_turned_nose_2.png"
        attribute n3:
            "mod_assets/layeredimage/yuri/yuri_turned_nose_3.png"



    group eyes:
        anchor (0,0) subpixel (True)

        attribute oe default if_all(["neut"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_1.png"
        attribute oe default if_all(["happ"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_3.png"
        attribute oe default if_all(["worr"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_4.png"
        attribute oe default if_any(["angr","flus"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_5.png"
        attribute oe default if_any(["vang","lsur"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_2.png"
        attribute oe default if_any(["yand","shoc","vsur"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_8.png"


        attribute ce if_any(["neut","happ","yand"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_6.png"
        attribute ce if_any(["worr","angr","vang","flus","lsur","shoc","vsur"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_7.png"


        attribute e1:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_6.png"
        attribute e7:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_7.png"
        attribute e8:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_8.png"
        attribute e9:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_9.png"
        attribute ea:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_a.png"
        attribute eb:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_b.png"
        attribute ec:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_c.png"
        attribute ed:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_d.png"
        attribute ee:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_e.png"
        attribute ef:
            "mod_assets/layeredimage/yuri/yuri_turned_eyes_f.png"



    group brow:
        anchor (0,0) subpixel (True)

        attribute brow default if_all(["neut"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_1.png"
        attribute brow default if_all(["happ"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_3.png"
        attribute brow default if_all(["worr"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_2.png"
        attribute brow default if_all(["angr"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_4.png"
        attribute brow default if_all(["vang"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_6.png"
        attribute brow default if_any(["yand","shoc","vsur"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_8.png"
        attribute brow default if_any(["flus","lsur"]):
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_5.png"



        attribute b1:
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_1.png"
        attribute b2 if_not(["e8","ef","yand","shoc","vsur"]): 
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_2.png"
        attribute b3:
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_3.png"
        attribute b4 if_not(["e8","ef","yand","shoc","vsur"]): 
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_4.png"
        attribute b5:
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_5.png"
        attribute b6 if_not(["e8","ef","yand","shoc","vsur"]): 
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_6.png"
        attribute b7 if_not(["e8","ef","yand","shoc","vsur"]): 
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_7.png"
        attribute b8:
            "mod_assets/layeredimage/yuri/yuri_turned_eyebrows_8.png"




image stabbing_n:

    "mod_assets/layeredimage/yuri/yuri_turned_stab_4.png"
    0.5
    "mod_assets/layeredimage/yuri/yuri_turned_stab_5.png"
    0.5

    repeat

image stabbing_f:

    "mod_assets/layeredimage/yuri/yuri_turned_stab_4.png"
    0.25
    "mod_assets/layeredimage/yuri/yuri_turned_stab_5.png"
    0.25

    repeat

image stabbing_t:

    "mod_assets/layeredimage/yuri/yuri_turned_stab_4.png"
    0.05
    "mod_assets/layeredimage/yuri/yuri_turned_stab_5.png"
    0.05

    repeat

image stabbing_n_start:

    "mod_assets/layeredimage/yuri/yuri_turned_stab_1.png"
    1.0
    "mod_assets/layeredimage/yuri/yuri_turned_stab_2.png"
    0.5
    "mod_assets/layeredimage/yuri/yuri_turned_stab_3.png"
    0.5
    "mod_assets/layeredimage/yuri/yuri_turned_stab_4.png"

image stabbing_f_start:

    "mod_assets/layeredimage/yuri/yuri_turned_stab_1.png"
    0.5
    "mod_assets/layeredimage/yuri/yuri_turned_stab_2.png"
    0.25
    "mod_assets/layeredimage/yuri/yuri_turned_stab_3.png"
    0.25
    "mod_assets/layeredimage/yuri/yuri_turned_stab_4.png"


image stabbing_t_start:

    "mod_assets/layeredimage/yuri/yuri_turned_stab_1.png"
    0.1
    "mod_assets/layeredimage/yuri/yuri_turned_stab_2.png"
    0.05
    "mod_assets/layeredimage/yuri/yuri_turned_stab_3.png"
    0.05
    "mod_assets/layeredimage/yuri/yuri_turned_stab_4.png"

image stabbing_n_end:

    "mod_assets/layeredimage/yuri/yuri_turned_stab_5.png"
    0.5
    "mod_assets/layeredimage/yuri/yuri_turned_stab_6.png"

image stabbing_f_end:

    "mod_assets/layeredimage/yuri/yuri_turned_stab_5.png"
    0.25
    "mod_assets/layeredimage/yuri/yuri_turned_stab_6.png"

image stabbing_t_end:

    "mod_assets/layeredimage/yuri/yuri_turned_stab_5.png"
    0.05
    "mod_assets/layeredimage/yuri/yuri_turned_stab_6.png"


layeredimage yuri shy:

    always "mod_assets/layeredimage/yuri/yuri_shy_facebase.png"

    group outfit: 
        anchor (0,0) subpixel (True)
        attribute uniform default:
            "mod_assets/layeredimage/yuri/yuri_shy_uniform_bodybase.png"
        attribute casual:
            "mod_assets/layeredimage/yuri/yuri_shy_casual_bodybase.png"
        attribute hoodie:
            "mod_assets/layeredimage/yuri/yuri_shy_hoodie_bodybase.png"

    group placeholder: 
        attribute tape:
            "mod_assets/layeredimage/yuri/yuri_duct_tape.png"

    group mood:
        attribute neut default null 
        attribute happ null 
        attribute sad null 
        attribute angr null 





    group mouth:
        anchor (0,0) subpixel (True)

        attribute cm default if_all(["neut"]):
            "mod_assets/layeredimage/yuri/yuri_shy_mouth_1.png"
        attribute cm default if_all(["happ"]):
            "mod_assets/layeredimage/yuri/yuri_shy_mouth_3.png"
        attribute cm default if_any(["angr","sad"]):
            "mod_assets/layeredimage/yuri/yuri_shy_mouth_2.png"


        attribute om:
            "mod_assets/layeredimage/yuri/yuri_shy_mouth_4.png"


        attribute m1:
            "mod_assets/layeredimage/yuri/yuri_shy_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/yuri/yuri_shy_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/yuri/yuri_shy_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/yuri/yuri_shy_mouth_4.png"

    group nose:
        anchor (0,0) subpixel (True)
        attribute nose default: 
            "mod_assets/layeredimage/yuri/yuri_shy_nose_1.png"


        attribute n1:
            "mod_assets/layeredimage/yuri/yuri_shy_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/yuri/yuri_shy_nose_2.png"
        attribute n3: 
            "mod_assets/layeredimage/yuri/yuri_shy_nose_3.png"


    group eyes if_not(["n3"]): 
        anchor (0,0) subpixel (True)
        attribute oe default if_all(["neut"]):
            "mod_assets/layeredimage/yuri/yuri_shy_eyes_2.png"
        attribute oe default if_all(["happ"]):
            "mod_assets/layeredimage/yuri/yuri_shy_eyes_1.png"
        attribute oe default if_any(["angr","sad"]):
            "mod_assets/layeredimage/yuri/yuri_shy_eyes_3.png"


        attribute e1:
            "mod_assets/layeredimage/yuri/yuri_shy_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/yuri/yuri_shy_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/yuri/yuri_shy_eyes_3.png"

    group eyebrows if_not(["n3"]): 
        anchor (0,0) subpixel (True)
        attribute brow default if_any(["neut","sad"]):
            "mod_assets/layeredimage/yuri/yuri_shy_eyebrows_2.png"
        attribute brow default if_all(["happ"]):
            "mod_assets/layeredimage/yuri/yuri_shy_eyebrows_1.png"
        attribute brow default if_any(["angr"]):
            "mod_assets/layeredimage/yuri/yuri_shy_eyebrows_3.png"



        attribute b1:
            "mod_assets/layeredimage/yuri/yuri_shy_eyebrows_1.png"
        attribute b2:
            "mod_assets/layeredimage/yuri/yuri_shy_eyebrows_2.png"
        attribute b3:
            "mod_assets/layeredimage/yuri/yuri_shy_eyebrows_3.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
