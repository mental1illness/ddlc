

layeredimage sayori turned: 

    always "mod_assets/layeredimage/sayori/sayori_turned_facebase.png" 

    group outfit: 
        attribute uniform default null
        attribute casual null
        attribute pajamas null
        attribute hoodie null


    group mood: 

        attribute neut default null 
        attribute happ null 
        attribute sad null 
        attribute angr null 
        attribute pani null 
        attribute surp null 
        attribute dist null 
        attribute vang null 
        attribute anno null 

    group blush: 
        attribute nobl null 
        attribute awkw null 
        attribute blus null 




    group left if_all(["uniform"]):
        attribute ldown default:
            "mod_assets/layeredimage/sayori/sayori_turned_uniform_left_down.png"
        attribute lup:
            "mod_assets/layeredimage/sayori/sayori_turned_uniform_left_up.png"
        attribute lknife:
            "mod_assets/layeredimage/sayori/sayori_turned_uniform_left_knife.png"

    group left if_all(["casual"]):
        attribute ldown default:
            "mod_assets/layeredimage/sayori/sayori_turned_casual_left_down.png"
        attribute lup:
            "mod_assets/layeredimage/sayori/sayori_turned_casual_left_up.png"

    group left if_all(["pajamas"]):
        attribute ldown default:
            "mod_assets/layeredimage/sayori/sayori_turned_pajamas_left_down.png"
        attribute lup:
            "mod_assets/layeredimage/sayori/sayori_turned_pajamas_left_up.png"

    group left if_all(["hoodie"]):
        yoffset (-1)
        attribute ldown default:
            "mod_assets/layeredimage/sayori/sayori_turned_hoodie_left_down.png"
        attribute lup:
            "mod_assets/layeredimage/sayori/sayori_turned_hoodie_left_up.png"



    group right if_all(["uniform"]):
        attribute rdown default:
            "mod_assets/layeredimage/sayori/sayori_turned_uniform_right_down.png"
        attribute rup:
            "mod_assets/layeredimage/sayori/sayori_turned_uniform_right_up.png"
        attribute rknife:
            "mod_assets/layeredimage/sayori/sayori_turned_uniform_right_knife.png"

    group right if_all(["casual"]):
        attribute rdown default:
            "mod_assets/layeredimage/sayori/sayori_turned_casual_right_down.png"
        attribute rup:
            "mod_assets/layeredimage/sayori/sayori_turned_casual_right_up.png"

    group right if_all(["pajamas"]):
        attribute rdown default:
            "mod_assets/layeredimage/sayori/sayori_turned_pajamas_right_down.png"
        attribute rup:
            "mod_assets/layeredimage/sayori/sayori_turned_pajamas_right_up.png"

    group right if_all(["hoodie"]):
        yoffset (-1)
        attribute rdown default:
            "mod_assets/layeredimage/sayori/sayori_turned_hoodie_right_down.png"
        attribute rup:
            "mod_assets/layeredimage/sayori/sayori_turned_hoodie_right_up.png"

    group placeholder:
        attribute rope:
            "mod_assets/layeredimage/sayori/sayori_turned_rope.png"

    group mouth:


        attribute cm default if_any(["neut"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_a.png"
        attribute cm default if_any(["happ"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_1.png"
        attribute cm default if_any(["sad","anno"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_6.png"
        attribute cm default if_any(["angr","vang"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_8.png"
        attribute cm default if_any(["pani"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_4.png"
        attribute cm default if_any(["surp"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_4.png"
        attribute cm default if_any(["dist"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_5.png"



        attribute om if_any(["neut"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_3.png"
        attribute om if_any(["happ"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_2.png"
        attribute om if_any(["sad","anno"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_3.png"
        attribute om if_any(["angr","vang"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_7.png"
        attribute om if_any(["pani"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_7.png"
        attribute om if_any(["surp"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_3.png"
        attribute om if_any(["dist"]):
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_3.png"


        attribute m1:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_4.png"
        attribute m5:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_5.png"
        attribute m6:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_6.png"
        attribute m7:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_7.png"
        attribute m8:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_8.png"
        attribute m9:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_9.png"
        attribute ma:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_a.png"
        attribute mb:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_b.png"
        attribute mc:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_c.png"
        attribute md:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_d.png"
        attribute me:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_e.png"
        attribute mf:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_f.png"
        attribute mg:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_g.png"
        attribute mh:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_h.png"
        attribute mi:
            "mod_assets/layeredimage/sayori/sayori_turned_mouth_i.png"



    group nose:


        attribute nose default if_any(["nobl"]):
            "mod_assets/layeredimage/sayori/sayori_turned_nose_1.png"
        attribute nose default if_any(["awkw"]):
            "mod_assets/layeredimage/sayori/sayori_turned_nose_2.png"
        attribute nose default if_any(["blus"]):
            "mod_assets/layeredimage/sayori/sayori_turned_nose_3.png"



        attribute n1:
            "mod_assets/layeredimage/sayori/sayori_turned_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/sayori/sayori_turned_nose_2.png"
        attribute n3:
            "mod_assets/layeredimage/sayori/sayori_turned_nose_3.png"



    group eyes:


        attribute oe default if_any(["neut","anno"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_1.png"
        attribute oe default if_any(["happ"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_1.png"
        attribute oe default if_any(["sad"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_5.png"
        attribute oe default if_any(["angr"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_h.png"
        attribute oe default if_any(["pani"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_3.png"
        attribute oe default if_any(["surp"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_3.png"
        attribute oe default if_any(["dist"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_2.png"
        attribute oe default if_any(["vang"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_y.png"


        attribute ce if_any(["neut"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_4.png"
        attribute ce if_any(["happ"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_4.png"
        attribute ce if_any(["sad","anno"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_9.png"
        attribute ce if_any(["angr"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_9.png"
        attribute ce if_any(["pani","vang"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_6.png"
        attribute ce if_any(["surp"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_4.png"
        attribute ce if_any(["dist"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_9.png"


        attribute e1:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_6.png"
        attribute e7:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_7.png"
        attribute e8:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_8.png"
        attribute e9:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_9.png"
        attribute ea:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_a.png"
        attribute eb:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_b.png"
        attribute ec:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_c.png"
        attribute ed:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_d.png"
        attribute ee:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_e.png"
        attribute ef:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_f.png"
        attribute eg:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_g.png"
        attribute eh:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_h.png"
        attribute ei:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_i.png"
        attribute ej:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_j.png"
        attribute ey:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_y.png"
        attribute ez:
            "mod_assets/layeredimage/sayori/sayori_turned_eyes_z.png"



    group brow:


        attribute brow default if_any(["neut"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_1.png"
        attribute brow default if_any(["happ"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_1.png"
        attribute brow default if_any(["sad"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_2.png"
        attribute brow default if_any(["angr","anno"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_4.png"
        attribute brow default if_any(["pani"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_2.png"
        attribute brow default if_any(["surp"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_1.png"
        attribute brow default if_any(["dist"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_3.png"
        attribute brow default if_any(["vang"]):
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_6.png"



        attribute b1:
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_1.png"
        attribute b2:
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_2.png"
        attribute b3:
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_3.png"
        attribute b4:
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_4.png"
        attribute b5:
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_5.png"
        attribute b6:
            "mod_assets/layeredimage/sayori/sayori_turned_eyebrows_6.png"




layeredimage sayori tap: 

    group body: 
        attribute fing default:
            "mod_assets/layeredimage/sayori/sayori_tapping_uniform_bodybase.png"
        attribute arms:
            "mod_assets/layeredimage/sayori/sayori_tapping_uniform_bodyarmsout.png"
        attribute undress:
            "mod_assets/layeredimage/sayori/sayori_tapping_uniform_bodyundress.png"

    always "mod_assets/layeredimage/sayori/sayori_tapping_facebase.png" 

    group mood: 

        attribute neut default null 
        attribute happ null 
        attribute sad null 
        attribute pout null 
        attribute pani null 
        attribute dist null 
        attribute sedu null 

    group blush: 
        attribute nobl default null 
        attribute awkw null 
        attribute blus null 


    group mouth:


        attribute cm default if_any(["neut"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_3.png"
        attribute cm default if_any(["happ"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_4.png"
        attribute cm default if_any(["sad"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_3.png"
        attribute cm default if_any(["pout"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_2.png"
        attribute cm default if_any(["pani"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_6.png"
        attribute cm default if_any(["dist"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_3.png"
        attribute cm default if_any(["sedu"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_4.png"


        attribute om if_any(["neut"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_1.png"
        attribute om if_any(["happ"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_1.png"
        attribute om if_any(["sad"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_5.png"
        attribute om if_any(["pout"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_5.png"
        attribute om if_any(["pani"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_7.png"
        attribute om if_any(["dist"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_5.png"
        attribute om if_any(["sedu"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_1.png"


        attribute m1:
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_4.png"
        attribute m5:
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_5.png"
        attribute m6:
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_6.png"
        attribute m7:
            "mod_assets/layeredimage/sayori/sayori_tapping_mouth_7.png"


    group nose:


        attribute nose default if_any(["nobl"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_nose_1.png"
        attribute nose default if_any(["awkw"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_nose_2.png"
        attribute nose default if_any(["blus"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_nose_z.png"



        attribute n1:
            "mod_assets/layeredimage/sayori/sayori_tapping_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/sayori/sayori_tapping_nose_2.png"
        attribute nz:
            "mod_assets/layeredimage/sayori/sayori_tapping_nose_z.png"




    group eyes:


        attribute oe default if_any(["neut"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_1.png"
        attribute oe default if_any(["happ"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_1.png"
        attribute oe default if_any(["sad"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_2.png"
        attribute oe default if_any(["pout"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_2.png"
        attribute oe default if_any(["pani"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_z.png"
        attribute oe default if_any(["dist"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_2.png"
        attribute oe default if_any(["sedu"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_y.png"



        attribute e1:
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_2.png"
        attribute ey:
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_y.png"
        attribute ez:
            "mod_assets/layeredimage/sayori/sayori_tapping_eyes_z.png"




    group brow:


        attribute brow default if_any(["neut"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyebrows_1.png"
        attribute brow default if_any(["happ"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyebrows_1.png"
        attribute brow default if_any(["sad"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyebrows_1.png"
        attribute brow default if_any(["pout"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyebrows_2.png"
        attribute brow default if_any(["pani"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyebrows_1.png"
        attribute brow default if_any(["dist"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyebrows_2.png"
        attribute brow default if_any(["sedu"]):
            "mod_assets/layeredimage/sayori/sayori_tapping_eyebrows_2.png"



        attribute b1:
            "mod_assets/layeredimage/sayori/sayori_tapping_eyebrows_1.png"
        attribute b2:
            "mod_assets/layeredimage/sayori/sayori_tapping_eyebrows_2.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
