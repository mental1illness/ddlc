

layeredimage monika forward: 

    always "mod_assets/layeredimage/monika/monika_forward_facebase.png" 

    group outfit: 

        attribute uniform default null
        attribute casual null


    group mood: 

        attribute neut default null 
        attribute happ null 
        attribute cry null 
        attribute anno null 
        attribute vang null 
        attribute shoc null 
        attribute worr null 


    group blush: 
        attribute nobl null 
        attribute awkw null 
        attribute blus null 



    group left:
        attribute ldown default if_all(["uniform"]):
            "mod_assets/layeredimage/monika/monika_forward_uniform_left_down.png"
        attribute ldown default if_all(["casual"]):
            "mod_assets/layeredimage/monika/monika_forward_casual_left_down.png"
        attribute lpoint if_all(["uniform"]):
            "mod_assets/layeredimage/monika/monika_forward_uniform_left_point.png"
        attribute lpoint if_all(["casual"]):
            "mod_assets/layeredimage/monika/monika_forward_casual_left_point.png"
        attribute lknife if_all(["uniform"]):
            "mod_assets/layeredimage/monika/monika_forward_uniform_left_knife.png"
        attribute lknife if_all(["casual"]):
            "mod_assets/layeredimage/monika/monika_forward_casual_left_knife.png"

    group right:
        attribute rdown default if_all(["uniform"]):
            "mod_assets/layeredimage/monika/monika_forward_uniform_right_down.png"
        attribute rdown default if_all(["casual"]):
            "mod_assets/layeredimage/monika/monika_forward_casual_right_down.png"
        attribute rhip if_all(["uniform"]):
            "mod_assets/layeredimage/monika/monika_forward_uniform_right_hip.png"
        attribute rhip if_all(["casual"]):
            "mod_assets/layeredimage/monika/monika_forward_casual_right_hip.png"
        attribute rknife if_all(["uniform"]):
            "mod_assets/layeredimage/monika/monika_forward_uniform_right_knife.png"
        attribute rknife if_all(["casual"]):
            "mod_assets/layeredimage/monika/monika_forward_casual_right_knife.png"

    group mouth:


        attribute cm default if_any(["neut","worr","anno"]):
            "mod_assets/layeredimage/monika/monika_forward_mouth_3.png"
        attribute cm default if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_forward_mouth_1.png"
        attribute cm default if_all(["cry"]):
            "mod_assets/layeredimage/monika/monika_forward_mouth_c.png"
        attribute cm default if_all(["vang"]):
            "mod_assets/layeredimage/monika/monika_forward_mouth_z.png"
        attribute cm default if_all(["shoc"]):
            "mod_assets/layeredimage/monika/monika_forward_mouth_a.png"


        attribute om if_any(["neut","worr","anno"]):
            "mod_assets/layeredimage/monika/monika_forward_mouth_4.png"
        attribute om if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_forward_mouth_2.png"
        attribute om if_any(["cry","shoc"]):
            "mod_assets/layeredimage/monika/monika_forward_mouth_7.png"
        attribute om if_all(["vang"]):
            "mod_assets/layeredimage/monika/monika_forward_mouth_5.png"


        attribute m1:
            "mod_assets/layeredimage/monika/monika_forward_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/monika/monika_forward_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/monika/monika_forward_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/monika/monika_forward_mouth_4.png"
        attribute m5:
            "mod_assets/layeredimage/monika/monika_forward_mouth_5.png"
        attribute m6:
            "mod_assets/layeredimage/monika/monika_forward_mouth_6.png"
        attribute m7:
            "mod_assets/layeredimage/monika/monika_forward_mouth_7.png"
        attribute m8:
            "mod_assets/layeredimage/monika/monika_forward_mouth_8.png"
        attribute m9:
            "mod_assets/layeredimage/monika/monika_forward_mouth_9.png"
        attribute ma:
            "mod_assets/layeredimage/monika/monika_forward_mouth_a.png"
        attribute mb:
            "mod_assets/layeredimage/monika/monika_forward_mouth_b.png"
        attribute mc:
            "mod_assets/layeredimage/monika/monika_forward_mouth_c.png"
        attribute md:
            "mod_assets/layeredimage/monika/monika_forward_mouth_d.png"
        attribute me:
            "mod_assets/layeredimage/monika/monika_forward_mouth_e.png"
        attribute mf:
            "mod_assets/layeredimage/monika/monika_forward_mouth_f.png"
        attribute mg:
            "mod_assets/layeredimage/monika/monika_forward_mouth_g.png"
        attribute my:
            "mod_assets/layeredimage/monika/monika_forward_mouth_y.png"
        attribute mz:
            "mod_assets/layeredimage/monika/monika_forward_mouth_z.png"



    group nose:


        attribute nose default if_all(["nobl"]):
            "mod_assets/layeredimage/monika/monika_forward_nose_1.png"
        attribute nose default if_all(["awkw"]):
            "mod_assets/layeredimage/monika/monika_forward_nose_2.png"
        attribute nose default if_all(["blus"]):
            "mod_assets/layeredimage/monika/monika_forward_nose_3.png"



        attribute n1:
            "mod_assets/layeredimage/monika/monika_forward_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/monika/monika_forward_nose_2.png"
        attribute n3:
            "mod_assets/layeredimage/monika/monika_forward_nose_3.png"



    group eyes:


        attribute oe default if_any(["neut","happ"]):
            "mod_assets/layeredimage/monika/monika_forward_eyes_1.png"
        attribute oe default if_any(["worr"]):
            "mod_assets/layeredimage/monika/monika_forward_eyes_2.png"
        attribute oe default if_all(["cry"]):
            "mod_assets/layeredimage/monika/monika_forward_eyes_8.png"
        attribute oe default if_all(["anno"]):
            "mod_assets/layeredimage/monika/monika_forward_eyes_9.png"
        attribute oe default if_any(["vang","shoc"]):
            "mod_assets/layeredimage/monika/monika_forward_eyes_7.png"


        attribute ce if_any(["neut","anno","vang","shoc","worr"]):
            "mod_assets/layeredimage/monika/monika_forward_eyes_4.png"
        attribute ce if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_forward_eyes_3.png"
        attribute ce if_all(["cry"]):
            "mod_assets/layeredimage/monika/monika_forward_eyes_g.png"


        attribute e1:
            "mod_assets/layeredimage/monika/monika_forward_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/monika/monika_forward_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/monika/monika_forward_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/monika/monika_forward_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/monika/monika_forward_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/monika/monika_forward_eyes_6.png"
        attribute e7:
            "mod_assets/layeredimage/monika/monika_forward_eyes_7.png"
        attribute e8:
            "mod_assets/layeredimage/monika/monika_forward_eyes_8.png"
        attribute e9:
            "mod_assets/layeredimage/monika/monika_forward_eyes_9.png"
        attribute ea:
            "mod_assets/layeredimage/monika/monika_forward_eyes_a.png"
        attribute eb:
            "mod_assets/layeredimage/monika/monika_forward_eyes_b.png"
        attribute ec:
            "mod_assets/layeredimage/monika/monika_forward_eyes_c.png"
        attribute ed:
            "mod_assets/layeredimage/monika/monika_forward_eyes_d.png"
        attribute ee:
            "mod_assets/layeredimage/monika/monika_forward_eyes_e.png"
        attribute ef:
            "mod_assets/layeredimage/monika/monika_forward_eyes_f.png"
        attribute eg:
            "mod_assets/layeredimage/monika/monika_forward_eyes_g.png"
        attribute eh:
            "mod_assets/layeredimage/monika/monika_forward_eyes_h.png"
        attribute ei:
            "mod_assets/layeredimage/monika/monika_forward_eyes_i.png"



    group brow:


        attribute brow default if_any(["neut","happ"]):
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_1.png"
        attribute brow default if_any(["cry","worr","shoc"]):
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_2.png"
        attribute brow default if_all(["anno"]):
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_3.png"
        attribute brow default if_all(["vang"]):
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_5.png"



        attribute b1:
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_1.png"
        attribute b2:
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_2.png"
        attribute b3:
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_3.png"
        attribute b4:
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_4.png"
        attribute b5:
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_5.png"
        attribute b6:
            "mod_assets/layeredimage/monika/monika_forward_eyebrows_6.png"






layeredimage monika lean:


    always "mod_assets/layeredimage/monika/monika_lean_bodybase.png"
    always "mod_assets/layeredimage/monika/monika_lean_facebase.png"

    group outfit: 

        attribute uniform default null
        attribute casual null


    group mood: 

        attribute neut null 
        attribute happ default null 
        attribute sad null 
        attribute angr null 
        attribute vang null 

    group blush: 
        attribute awkw null 
        attribute blus null 


    group mouth:


        attribute cm default if_all(["neut"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_b.png"
        attribute cm default if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_1.png"
        attribute cm default if_all(["sad"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_b.png"
        attribute cm default if_all(["angr"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_b.png"
        attribute cm default if_all(["vang"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_c.png"


        attribute om if_all(["neut"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_2.png"
        attribute om if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_z.png"
        attribute om if_all(["sad"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_d.png"
        attribute om if_all(["angr"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_f.png"
        attribute om if_all(["vang"]):
            "mod_assets/layeredimage/monika/monika_lean_mouth_e.png"


        attribute m1:
            "mod_assets/layeredimage/monika/monika_lean_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/monika/monika_lean_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/monika/monika_lean_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/monika/monika_lean_mouth_4.png"
        attribute m5:
            "mod_assets/layeredimage/monika/monika_lean_mouth_5.png"
        attribute m6:
            "mod_assets/layeredimage/monika/monika_lean_mouth_6.png"
        attribute m7:
            "mod_assets/layeredimage/monika/monika_lean_mouth_7.png"
        attribute m8:
            "mod_assets/layeredimage/monika/monika_lean_mouth_8.png"
        attribute m9:
            "mod_assets/layeredimage/monika/monika_lean_mouth_9.png"
        attribute ma:
            "mod_assets/layeredimage/monika/monika_lean_mouth_a.png"
        attribute mb:
            "mod_assets/layeredimage/monika/monika_lean_mouth_b.png"
        attribute mc:
            "mod_assets/layeredimage/monika/monika_lean_mouth_c.png"
        attribute md:
            "mod_assets/layeredimage/monika/monika_lean_mouth_d.png"
        attribute me:
            "mod_assets/layeredimage/monika/monika_lean_mouth_e.png"
        attribute mf:
            "mod_assets/layeredimage/monika/monika_lean_mouth_f.png"
        attribute mz:
            "mod_assets/layeredimage/monika/monika_lean_mouth_z.png"


        attribute m_smile:
            "mod_assets/layeredimage/monika/monika_lean_mouth_1.png"
        attribute m_open:
            "mod_assets/layeredimage/monika/monika_lean_mouth_2.png"
        attribute m_closed:
            "mod_assets/layeredimage/monika/monika_lean_mouth_3.png"
        attribute m_pursed:
            "mod_assets/layeredimage/monika/monika_lean_mouth_4.png"
        attribute m_smile_wide:
            "mod_assets/layeredimage/monika/monika_lean_mouth_5.png"
        attribute m_grin:
            "mod_assets/layeredimage/monika/monika_lean_mouth_6.png"
        attribute m_pout:
            "mod_assets/layeredimage/monika/monika_lean_mouth_7.png"
        attribute m_angry:
            "mod_assets/layeredimage/monika/monika_lean_mouth_8.png"
        attribute m_grin_wide:
            "mod_assets/layeredimage/monika/monika_lean_mouth_9.png"
        attribute m_cat:
            "mod_assets/layeredimage/monika/monika_lean_mouth_a.png"
        attribute m_frown:
            "mod_assets/layeredimage/monika/monika_lean_mouth_b.png"
        attribute m_grit:
            "mod_assets/layeredimage/monika/monika_lean_mouth_c.png"
        attribute m_gasp:
            "mod_assets/layeredimage/monika/monika_lean_mouth_d.png"
        attribute m_shocked:
            "mod_assets/layeredimage/monika/monika_lean_mouth_e.png"
        attribute m_shout:
            "mod_assets/layeredimage/monika/monika_lean_mouth_f.png"
        attribute m_smile_med:
            "mod_assets/layeredimage/monika/monika_lean_mouth_z.png"

    group nose:


        attribute nose default if_not(["awkw","blus"]):
            "mod_assets/layeredimage/monika/monika_lean_nose_1.png"
        attribute nose default if_not(["blus"]) if_all(["awkw"]):
            "mod_assets/layeredimage/monika/monika_lean_nose_x.png"
        attribute nose default if_not(["awkw"]) if_all(["blus"]):
            "mod_assets/layeredimage/monika/monika_lean_nose_z.png"



        attribute n1:
            "mod_assets/layeredimage/monika/monika_lean_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/monika/monika_lean_nose_2.png"
        attribute nx:
            "mod_assets/layeredimage/monika/monika_lean_nose_x.png"
        attribute ny:
            "mod_assets/layeredimage/monika/monika_lean_nose_y.png"
        attribute nz:
            "mod_assets/layeredimage/monika/monika_lean_nose_z.png"



        attribute n_normal:
            "mod_assets/layeredimage/monika/monika_lean_nose_1.png"
        attribute n_blush:
            "mod_assets/layeredimage/monika/monika_lean_nose_2.png"
        attribute n_sweat:
            "mod_assets/layeredimage/monika/monika_lean_nose_x.png"
        attribute n_bl_sweat:
            "mod_assets/layeredimage/monika/monika_lean_nose_y.png"
        attribute 2_z:
            "mod_assets/layeredimage/monika/monika_lean_nose_z.png"

    group eyes:


        attribute oe default if_all(["neut"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_1.png"
        attribute oe default if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_1.png"
        attribute oe default if_all(["sad"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_b.png"
        attribute oe default if_all(["angr"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_2.png"
        attribute oe default if_all(["vang"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_y.png"


        attribute ce if_all(["neut"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_3.png"
        attribute ce if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_3.png"
        attribute ce if_all(["sad"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_3.png"
        attribute ce if_all(["angr"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_3.png"
        attribute ce if_all(["vang"]):
            "mod_assets/layeredimage/monika/monika_lean_eyes_3.png"


        attribute e1:
            "mod_assets/layeredimage/monika/monika_lean_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/monika/monika_lean_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/monika/monika_lean_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/monika/monika_lean_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/monika/monika_lean_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/monika/monika_lean_eyes_6.png"
        attribute e7:
            "mod_assets/layeredimage/monika/monika_lean_eyes_7.png"
        attribute e8:
            "mod_assets/layeredimage/monika/monika_lean_eyes_8.png"
        attribute e9:
            "mod_assets/layeredimage/monika/monika_lean_eyes_9.png"
        attribute ea:
            "mod_assets/layeredimage/monika/monika_lean_eyes_a.png"
        attribute eb:
            "mod_assets/layeredimage/monika/monika_lean_eyes_b.png"
        attribute ec:
            "mod_assets/layeredimage/monika/monika_lean_eyes_c.png"
        attribute ex:
            "mod_assets/layeredimage/monika/monika_lean_eyes_x.png"
        attribute ey:
            "mod_assets/layeredimage/monika/monika_lean_eyes_y.png"
        attribute ez:
            "mod_assets/layeredimage/monika/monika_lean_eyes_z.png"



        attribute e_normal:
            "mod_assets/layeredimage/monika/monika_lean_eyes_1.png"
        attribute e_squint:
            "mod_assets/layeredimage/monika/monika_lean_eyes_2.png"
        attribute e_closed:
            "mod_assets/layeredimage/monika/monika_lean_eyes_3.png"
        attribute e_crossed:
            "mod_assets/layeredimage/monika/monika_lean_eyes_4.png"
        attribute e_derp:
            "mod_assets/layeredimage/monika/monika_lean_eyes_5.png"
        attribute e_yand_lr:
            "mod_assets/layeredimage/monika/monika_lean_eyes_6.png"
        attribute e_yand_l:
            "mod_assets/layeredimage/monika/monika_lean_eyes_7.png"
        attribute e_wink:
            "mod_assets/layeredimage/monika/monika_lean_eyes_8.png"
        attribute e_wink_s:
            "mod_assets/layeredimage/monika/monika_lean_eyes_9.png"
        attribute e_uwa:
            "mod_assets/layeredimage/monika/monika_lean_eyes_a.png"
        attribute e_cry:
            "mod_assets/layeredimage/monika/monika_lean_eyes_b.png"
        attribute e_yand_g:
            "mod_assets/layeredimage/monika/monika_lean_eyes_c.png"
        attribute e_yand_gl:
            "mod_assets/layeredimage/monika/monika_lean_eyes_x.png"
        attribute e_yand_gr:
            "mod_assets/layeredimage/monika/monika_lean_eyes_y.png"
        attribute e_glance:
            "mod_assets/layeredimage/monika/monika_lean_eyes_z.png"

    group brow:


        attribute brow default if_all(["neut"]):
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_1.png"
        attribute brow default if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_1.png"
        attribute brow default if_all(["sad"]):
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_3.png"
        attribute brow default if_all(["angr"]):
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_2.png"
        attribute brow default if_all(["vang"]):
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_2.png"



        attribute b1:
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_1.png"
        attribute b2:
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_2.png"
        attribute b3:
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_3.png"
        attribute b4:
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_4.png"


        attribute b_normal:
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_1.png"
        attribute b_up:
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_2.png"
        attribute b_down:
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_3.png"
        attribute b_crossed:
            "mod_assets/layeredimage/monika/monika_lean_eyebrows_4.png"



layeredimage monika turned: 


    always "mod_assets/layeredimage/monika/monika_turned_facebase.png"



    group mood: 

        attribute neut null 
        attribute happ default null 
        attribute sad null 
        attribute angr null 
        attribute surp null 
        attribute pani null 

    group blush: 
        attribute awkw null 
        attribute blus null 


    group left:
        attribute ldown default:
            "mod_assets/layeredimage/monika/monika_turned_uniform_left_down.png"
        attribute lpoint:
            "mod_assets/layeredimage/monika/monika_turned_uniform_left_point.png"
        attribute lsdn:
            "mod_assets/layeredimage/monika/monika_turned_uniform_left_sayori_down.png"
        attribute lsup:
            "mod_assets/layeredimage/monika/monika_turned_uniform_left_sayori_up.png"


    group right:
        attribute rdown default:
            "mod_assets/layeredimage/monika/monika_turned_uniform_right_down.png"
        attribute rhip:
            "mod_assets/layeredimage/monika/monika_turned_uniform_right_hip.png"
        attribute rsdn:
            "mod_assets/layeredimage/monika/monika_turned_uniform_right_sayori_down.png"
        attribute rsup:
            "mod_assets/layeredimage/monika/monika_turned_uniform_right_sayori_up.png"

    group mouth:


        attribute cm default if_all(["neut"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_6.png"
        attribute cm default if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_1.png"
        attribute cm default if_all(["sad"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_6.png"
        attribute cm default if_all(["angr"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_6.png"
        attribute cm default if_all(["surp"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_3.png"
        attribute cm default if_all(["pani"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_5.png"


        attribute om if_all(["neut"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_4.png"
        attribute om if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_2.png"
        attribute om if_all(["sad"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_5.png"
        attribute om if_all(["angr"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_4.png"
        attribute om if_all(["surp"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_4.png"
        attribute om if_all(["pani"]):
            "mod_assets/layeredimage/monika/monika_turned_mouth_7.png"


        attribute m1:
            "mod_assets/layeredimage/monika/monika_turned_mouth_1.png"
        attribute m2:
            "mod_assets/layeredimage/monika/monika_turned_mouth_2.png"
        attribute m3:
            "mod_assets/layeredimage/monika/monika_turned_mouth_3.png"
        attribute m4:
            "mod_assets/layeredimage/monika/monika_turned_mouth_4.png"
        attribute m5:
            "mod_assets/layeredimage/monika/monika_turned_mouth_5.png"
        attribute m6:
            "mod_assets/layeredimage/monika/monika_turned_mouth_6.png"
        attribute m7:
            "mod_assets/layeredimage/monika/monika_turned_mouth_7.png"



    group nose:


        attribute nose default if_not(["awkw","blus"]):
            "mod_assets/layeredimage/monika/monika_turned_nose_1.png"
        attribute nose default if_not(["blus"]) if_all(["awkw"]):
            "mod_assets/layeredimage/monika/monika_turned_nose_2.png"
        attribute nose default if_not(["awkw"]) if_all(["blus"]):
            "mod_assets/layeredimage/monika/monika_turned_nose_3.png"



        attribute n1:
            "mod_assets/layeredimage/monika/monika_turned_nose_1.png"
        attribute n2:
            "mod_assets/layeredimage/monika/monika_turned_nose_2.png"
        attribute n3:
            "mod_assets/layeredimage/monika/monika_turned_nose_3.png"



    group eyes:


        attribute oe default if_all(["neut"]):
            "mod_assets/layeredimage/monika/monika_turned_eyes_1.png"
        attribute oe default if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_turned_eyes_1.png"
        attribute oe default if_all(["sad"]):
            "mod_assets/layeredimage/monika/monika_turned_eyes_4.png"
        attribute oe default if_all(["angr"]):
            "mod_assets/layeredimage/monika/monika_turned_eyes_2.png"
        attribute oe default if_all(["surp"]):
            "mod_assets/layeredimage/monika/monika_turned_eyes_3.png"
        attribute oe default if_all(["pani"]):
            "mod_assets/layeredimage/monika/monika_turned_eyes_6.png"



        attribute e1:
            "mod_assets/layeredimage/monika/monika_turned_eyes_1.png"
        attribute e2:
            "mod_assets/layeredimage/monika/monika_turned_eyes_2.png"
        attribute e3:
            "mod_assets/layeredimage/monika/monika_turned_eyes_3.png"
        attribute e4:
            "mod_assets/layeredimage/monika/monika_turned_eyes_4.png"
        attribute e5:
            "mod_assets/layeredimage/monika/monika_turned_eyes_5.png"
        attribute e6:
            "mod_assets/layeredimage/monika/monika_turned_eyes_6.png"



    group brow:


        attribute brow default if_all(["neut"]):
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_1.png"
        attribute brow default if_all(["happ"]):
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_4.png"
        attribute brow default if_all(["sad"]):
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_2.png"
        attribute brow default if_all(["angr"]):
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_3.png"
        attribute brow default if_all(["surp"]):
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_4.png"
        attribute brow default if_all(["pani"]):
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_2.png"




        attribute b1:
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_1.png"
        attribute b2:
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_2.png"
        attribute b3:
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_3.png"
        attribute b4:
            "mod_assets/layeredimage/monika/monika_turned_eyebrows_4.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
